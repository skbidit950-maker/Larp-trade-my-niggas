# MarketMind AI Trading Arena

A self-contained browser-based trading simulator. Open `index.html` in a modern browser.

## Included
- Simulated market prices, chart, portfolio, manual orders, fees and P&L.
- Four local rule-based strategy agents that influence simulated prices and trades.
- Searchable directory of 30 real public trading/finance AI projects and infrastructure repositories, with source links.
- Links to broader curated ecosystem maps covering 70 agentic-trading repositories and 450+ open-source trading projects.

## Important distinction
The directory lists third-party projects; it does **not** install, run, or connect them. The four agents in the demo are simple local strategy simulations, not external AI models. All market prices and fills are fictional. No broker, exchange, wallet, API key, or real-money execution is connected. The directory is curated rather than exhaustive: new projects appear continuously, and each repository's capabilities, license, maintenance, and security should be checked before use.

## Research starting points
- https://github.com/orangejustin/awesome-agentic-trading (curated agentic trading repository map)
- https://github.com/WallStreetPete/awesome-open-source-trading (broad open-source trading project map)
- https://github.com/LLMQuant/awesome-trading-agents (LLM trading agents, MCP servers and skills)
- https://github.com/aowang-ai/awesome-finance-agents (finance-agent catalogue)

Educational software only; not financial advice. Backtests and repository popularity do not establish profitability.
